# WILDERNESS MOBILE — projeto preparado para exportação Android

## O que foi preparado
- Mantido o conteúdo original do projeto (cenas, scripts e textura).
- Renderizador Compatibility / GLES, apropriado para uma ampla faixa de dispositivos.
- Preset Android em `export_presets.cfg` com arquitetura **ARM 32-bit (armeabi-v7a)** habilitada e outras arquiteturas desabilitadas.
- Caminho de saída configurado para `build/WILDERNESS_MOBILE.apk`.

## Versão do Godot
O projeto original só declara “Godot 4.x” no `project.godot` e no README. Não há metadado suficiente para determinar a versão exata do editor/engine. Abra com uma versão Godot 4.x que suporte o preset Android e evite migrar para outra versão sem backup.

## Como gerar o APK
1. Instale o Godot 4.x e, no editor, instale os **Export Templates** correspondentes exatamente à versão do editor.
2. Instale/configure o Android SDK, JDK e ferramentas exigidas pela documentação da sua versão do Godot. Em Godot, abra **Editor > Editor Settings > Export > Android** e informe os caminhos.
3. Abra `project.godot`.
4. Vá a **Project > Export**, selecione o preset Android e confirme que a arquitetura `armeabi-v7a` está habilitada.
5. Clique em **Export Project** e escolha `build/WILDERNESS_MOBILE.apk` (ou use o caminho predefinido).
6. Instale o APK no aparelho Android. O APK ARM 32-bit só funcionará em dispositivo compatível com aplicativos armeabi-v7a.

## Limitações e validação
- Este ambiente não tem o executável Godot nem os templates/SDK Android configurados; portanto **não foi possível executar o editor, validar/importar todos os scripts no engine nem compilar/testar o APK**.
- O projeto-fonte é experimental; o README original já informa que os controles touch são iniciais. Não foram removidas mecânicas ou recursos para contornar isso.
- Antes de distribuir, configure assinatura de release e teste no aparelho-alvo. A assinatura padrão do editor serve para teste, não para publicação.

## Estrutura
`Main.tscn`, `project.godot`, `export_presets.cfg`, `scripts/`, `textures/`.
