extends CharacterBody3D

var camera: Camera3D
var move_input := Vector2.ZERO
var speed := 4.5
var gravity := 18.0

func physics_step(delta: float) -> void:
    var direction := global_transform.basis.x * move_input.x + -global_transform.basis.z * move_input.y
    direction.y = 0.0
    direction = direction.normalized()
    velocity.x = direction.x * speed
    velocity.z = direction.z * speed
    if not is_on_floor():
        velocity.y -= gravity * delta
    else:
        velocity.y = -0.2
    move_and_slide()
