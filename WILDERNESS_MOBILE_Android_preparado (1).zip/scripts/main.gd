extends Node3D

const PlayerScript=preload("res://scripts/player.gd")
const TreeScript=preload("res://scripts/tree.gd")
const EnemyScript=preload("res://scripts/enemy.gd")
var player: CharacterBody3D
var trees: Array[Node3D]=[]
var enemies: Array[Node3D]=[]
var inventory={"Madeira":0,"Pedra":0,"Fibra":0,"Comida":2,"Agua":2}
var health:=100.0
var hunger:=100.0
var thirst:=100.0
var day:=1
var clock:=8.0
var sun: DirectionalLight3D
var world_env: WorldEnvironment
var stats: Label
var bag: Label
var notice: Label
var craft: Panel
var attack_wait:=0.0
var touch_start:=Vector2.ZERO
var touch_move:=Vector2.ZERO
var moving_touch:=false
var look_id:=-1
var message_time:=0.0

func _ready():
    _input_setup()
    _environment()
    _make_world()
    _make_player()
    _make_ui()
    for i in range(3): _spawn_enemy()
    Input.mouse_mode=Input.MOUSE_MODE_CAPTURED
    _say("WILDERNESS // A floresta não está vazia.")

func _input_setup():
    for action in ["move_forward","move_back","move_left","move_right"]:
        if not InputMap.has_action(action): InputMap.add_action(action)
    _key("move_forward",KEY_W); _key("move_back",KEY_S)
    _key("move_left",KEY_A); _key("move_right",KEY_D)

func _key(action,keycode):
    var e=InputEventKey.new()
    e.physical_keycode=keycode
    InputMap.action_add_event(action,e)

func _process(delta):
    clock+=delta*0.035
    if clock>=24:
        clock=0
        day+=1
        _say("Dia %d. Continue sobrevivendo."%day)
        if day%2==0: _spawn_enemy()
    hunger=maxf(0,hunger-delta*0.09)
    thirst=maxf(0,thirst-delta*0.14)
    if hunger<=0 or thirst<=0: health=maxf(0,health-delta*2)
    attack_wait=maxf(0,attack_wait-delta)
    if message_time>0:
        message_time-=delta
        if message_time<=0: notice.text=""
    _lighting()
    _update_ui()

func _physics_process(delta):
    var axis=Vector2(Input.get_action_strength("move_right")-Input.get_action_strength("move_left"),Input.get_action_strength("move_back")-Input.get_action_strength("move_forward"))
    if moving_touch: axis=touch_move
    player.move_input=axis
    player.physics_step(delta)
    for e in enemies:
        if is_instance_valid(e): e.ai_step(player.global_position,delta,self)

func _input(event):
    if event is InputEventMouseMotion and Input.mouse_mode==Input.MOUSE_MODE_CAPTURED:
        player.rotate_y(-event.relative.x*0.0025)
        player.camera.rotate_x(-event.relative.y*0.0025)
        player.camera.rotation.x=clampf(player.camera.rotation.x,-1.35,1.35)
    if event is InputEventMouseButton and event.pressed and event.button_index==MOUSE_BUTTON_LEFT: _chop()
    if event is InputEventKey and event.pressed:
        if event.keycode==KEY_ESCAPE: Input.mouse_mode=Input.MOUSE_MODE_VISIBLE
        elif event.keycode==KEY_E: _collect()
        elif event.keycode==KEY_TAB: craft.visible=!craft.visible
        elif event.keycode==KEY_F: _consume()
        elif event.keycode==KEY_R: _chop()
        elif event.keycode==KEY_1: _craft("axe")
        elif event.keycode==KEY_2: _craft("fire")
        elif event.keycode==KEY_3: _craft("shelter")
    if event is InputEventScreenTouch:
        if event.pressed:
            if event.position.x<get_viewport().size.x*0.42 and event.position.y>get_viewport().size.y*0.48:
                moving_touch=true
                touch_start=event.position
                touch_move=Vector2.ZERO
            else: look_id=event.index
        else:
            if event.index==look_id: look_id=-1
            moving_touch=false
            touch_move=Vector2.ZERO
    if event is InputEventScreenDrag:
        if moving_touch: touch_move=(event.position-touch_start).limit_length(75)/75
        elif event.index==look_id:
            player.rotate_y(-event.relative.x*0.004)
            player.camera.rotate_x(-event.relative.y*0.004)
            player.camera.rotation.x=clampf(player.camera.rotation.x,-1.35,1.35)

func _mat(c:Color,rough:=1.0):
    var m=StandardMaterial3D.new()
    m.albedo_color=c
    m.roughness=rough
    return m

func _environment():
    world_env=WorldEnvironment.new()
    var e=Environment.new()
    e.background_mode=Environment.BG_SKY
    var sky=Sky.new()
    var sky_mat=ProceduralSkyMaterial.new()
    sky.sky_top_color=Color(0.12,0.19,0.22)
    sky.sky_horizon_color=Color(0.52,0.58,0.51)
    sky_mat.sky_top_color=Color(0.12,0.19,0.22)
    sky_mat.sky_horizon_color=Color(0.52,0.58,0.51)
    sky.sky_material=sky_mat
    e.sky=sky
    e.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color=Color(0.55,0.62,0.55)
    e.ambient_light_energy=0.65
    e.fog_enabled=true
    e.fog_light_color=Color(0.43,0.51,0.46)
    e.fog_density=0.012
    world_env.environment=e
    add_child(world_env)
    sun=DirectionalLight3D.new()
    sun.rotation_degrees=Vector3(-48,-32,0)
    sun.light_color=Color(1.0,0.88,0.72)
    sun.light_energy=1.0
    sun.shadow_enabled=true
    add_child(sun)

func _make_world():
    _static_box(Vector3(0,-0.6,0),Vector3(110,1,110),_mat(Color(0.18,0.27,0.18)))
    for i in range(90):
        var a=randf()*TAU
        var r=randf_range(13,48)
        var t=Node3D.new()
        t.position=Vector3(cos(a)*r,0,sin(a)*r)
        t.set_script(TreeScript)
        add_child(t)
        t.felled.connect(_tree_felled)
        trees.append(t)
    for i in range(40):
        var rock=MeshInstance3D.new()
        var sm=SphereMesh.new()
        sm.radius=randf_range(0.25,0.7)
        rock.mesh=sm
        rock.material_override=_mat(Color(0.36,0.39,0.37))
        rock.position=Vector3(randf_range(-45,45),0,randf_range(-45,45))
        rock.scale=Vector3(1.3,0.7,1)
        add_child(rock)
    var pond=MeshInstance3D.new()
    var cm=CylinderMesh.new()
    cm.top_radius=7
    cm.bottom_radius=7
    cm.height=0.08
    pond.mesh=cm
    pond.material_override=_mat(Color(0.10,0.29,0.32),0.25)
    pond.position=Vector3(25,-0.05,13)
    add_child(pond)

func _static_box(pos,size,mat):
    var body=StaticBody3D.new()
    body.position=pos
    var mi=MeshInstance3D.new()
    var mesh=BoxMesh.new()
    mesh.size=size
    mi.mesh=mesh
    mi.material_override=mat
    body.add_child(mi)
    var cs=CollisionShape3D.new()
    var shape=BoxShape3D.new()
    shape.size=size
    cs.shape=shape
    body.add_child(cs)
    add_child(body)

func _make_player():
    player=CharacterBody3D.new()
    player.set_script(PlayerScript)
    player.position=Vector3(0,1.1,5)
    add_child(player)
    var cam=Camera3D.new()
    cam.position=Vector3(0,0.55,0)
    cam.current=true
    player.add_child(cam)
    player.camera=cam
    var cs=CollisionShape3D.new()
    var cap=CapsuleShape3D.new()
    cap.radius=0.36
    cap.height=1.8
    cs.shape=cap
    player.add_child(cs)

func _spawn_enemy():
    var e=CharacterBody3D.new()
    e.set_script(EnemyScript)
    e.position=Vector3(cos(randf()*TAU)*randf_range(24,35),1,sin(randf()*TAU)*randf_range(24,35))
    add_child(e)
    enemies.append(e)

func _make_ui():
    var layer=CanvasLayer.new()
    add_child(layer)
    var root=Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    layer.add_child(root)
    var title=Label.new()
    title.text="W I L D E R N E S S"
    title.position=Vector2(22,16)
    title.add_theme_color_override("font_color",Color(0.91,0.85,0.70))
    title.add_theme_font_size_override("font_size",22)
    root.add_child(title)
    stats=Label.new()
    stats.position=Vector2(24,58)
    stats.size=Vector2(300,120)
    root.add_child(stats)
    bag=Label.new()
    bag.position=Vector2(24,185)
    bag.size=Vector2(340,100)
    root.add_child(bag)
    notice=Label.new()
    notice.position=Vector2(0,90)
    notice.size=Vector2(1280,40)
    notice.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
    notice.add_theme_color_override("font_color",Color(1,0.82,0.50))
    root.add_child(notice)
    var cross=Label.new()
    cross.text="+"
    cross.position=Vector2(630,344)
    root.add_child(cross)
    craft=Panel.new()
    craft.position=Vector2(900,85)
    craft.size=Vector2(350,290)
    craft.visible=false
    root.add_child(craft)
    var h=Label.new()
    h.text="OFICINA / TAB"
    h.position=Vector2(15,10)
    craft.add_child(h)
    _button(craft,"Machado [1]",Vector2(15,45),"axe")
    _button(craft,"Fogueira [2]",Vector2(15,95),"fire")
    _button(craft,"Abrigo [3]",Vector2(15,145),"shelter")
    _button(craft,"Fechar",Vector2(15,195),"close")
    _button(root,"MACHADO",Vector2(-140,-65),"chop",true)
    _button(root,"COLETAR",Vector2(-140,-120),"collect",true)
    _button(root,"MOCHILA",Vector2(20,-65),"bag",true)
    _button(root,"COMER/ÁGUA",Vector2(20,-120),"food",true)

func _button(parent,text_value,pos,action,anchored:=false):
    var b=Button.new()
    b.text=text_value
    b.size=Vector2(120,44)
    if anchored:
        b.anchor_left=1
        b.anchor_right=1
        b.anchor_top=1
        b.anchor_bottom=1
        b.offset_left=pos.x
        b.offset_top=pos.y
        b.offset_right=pos.x+120
        b.offset_bottom=pos.y+44
    else: b.position=pos
    if action in ["axe","fire","shelter","close"]: b.pressed.connect(_craft.bind(action))
    elif action=="chop": b.pressed.connect(_chop)
    elif action=="collect": b.pressed.connect(_collect)
    elif action=="bag": b.pressed.connect(func(): craft.visible=!craft.visible)
    elif action=="food": b.pressed.connect(_consume)
    parent.add_child(b)

func _update_ui():
    stats.text="VIDA  %d/100\nFOME  %d/100\nSEDE  %d/100\nDIA %02d   %02d:00"%[int(health),int(hunger),int(thirst),day,int(clock)]
    bag.text="MOCHILA\nMadeira %d   Pedra %d   Fibra %d\nComida %d   Água %d"%[inventory.Madeira,inventory.Pedra,inventory.Fibra,inventory.Comida,inventory.Agua]

func _say(s):
    notice.text=s
    message_time=4.0

func _chop():
    if attack_wait>0:return
    attack_wait=0.55
    var from=player.camera.global_position
    var to=from + -player.camera.global_basis.z*3.5
    var query=PhysicsRayQueryParameters3D.create(from,to)
    query.exclude=[player.get_rid()]
    var hit=get_world_3d().direct_space_state.intersect_ray(query)
    if hit and hit.collider:
        var node=hit.collider as Node
        while node and not node.has_method("chop"): node=node.get_parent()
        if node:
            var count=node.chop(hit.position)
            _say("Machadada %d/5 — o tronco está rachando."%count)
            return
    _say("Mire no tronco e chegue perto.")

func _tree_felled(amount,pos):
    inventory.Madeira+=amount
    _say("Árvore derrubada! +%d madeira."%amount)

func _collect():
    inventory.Pedra+=1
    inventory.Fibra+=1
    _say("+1 pedra e +1 fibra.")

func _craft(id):
    if id=="close": craft.visible=false
    elif id=="axe":
        if inventory.Madeira>=2 and inventory.Pedra>=2 and inventory.Fibra>=1:
            inventory.Madeira-=2; inventory.Pedra-=2; inventory.Fibra-=1
            _say("Machado de pedra criado.")
        else:_say("Precisa de 2 madeira, 2 pedras e 1 fibra.")
    elif id=="fire":
        if inventory.Madeira>=4 and inventory.Pedra>=2:
            inventory.Madeira-=4; inventory.Pedra-=2
            _say("Fogueira montada.")
        else:_say("Materiais insuficientes.")
    elif id=="shelter":
        if inventory.Madeira>=8:
            inventory.Madeira-=8
            _say("Abrigo montado.")
        else:_say("Precisa de 8 madeiras.")
    craft.visible=false

func _consume():
    if inventory.Agua>0 and thirst<90:
        inventory.Agua-=1; thirst=minf(100,thirst+35); _say("Você bebeu água.")
    elif inventory.Comida>0 and hunger<90:
        inventory.Comida-=1; hunger=minf(100,hunger+35); _say("Você comeu.")
    else:_say("Sem necessidade ou sem suprimentos.")

func _lighting():
    var daylight=clampf(sin((clock-6.0)/24.0*TAU)*0.5+0.5,0.15,1.0)
    sun.light_energy=0.2+daylight
    world_env.environment.ambient_light_energy=0.2+daylight*0.55
    world_env.environment.fog_light_color=Color(0.04,0.06,0.075).lerp(Color(0.43,0.51,0.46),daylight)
