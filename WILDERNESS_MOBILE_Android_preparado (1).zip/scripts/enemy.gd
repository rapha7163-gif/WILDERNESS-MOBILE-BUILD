extends CharacterBody3D
var hp := 100
var speed := 1.8
var cooldown := 0.0

func _ready() -> void:
    var body_mat := StandardMaterial3D.new()
    body_mat.albedo_color = Color(0.22,0.18,0.15)
    var torso := MeshInstance3D.new()
    var capsule := CapsuleMesh.new()
    capsule.radius = 0.38
    capsule.height = 1.45
    torso.mesh = capsule
    torso.material_override = body_mat
    torso.position.y = 0.82
    add_child(torso)
    var head := MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radius = 0.26
    head.mesh = sphere
    head.material_override = body_mat
    head.position.y = 1.55
    add_child(head)
    var collision := CollisionShape3D.new()
    var shape := CapsuleShape3D.new()
    shape.radius = 0.38
    shape.height = 1.7
    collision.shape = shape
    add_child(collision)

func ai_step(target: Vector3, delta: float, game: Node) -> void:
    var diff := target-global_position
    diff.y = 0
    if diff.length()<22.0 and diff.length()>1.7:
        var dir := diff.normalized()
        look_at(global_position+dir,Vector3.UP)
        velocity.x=dir.x*speed
        velocity.z=dir.z*speed
        move_and_slide()
    elif diff.length()<=1.7:
        cooldown-=delta
        if cooldown<=0:
            cooldown=1.6
            game.health=maxf(0.0,game.health-6.0)

func take_hit(damage: int) -> void:
    hp-=damage
    if hp<=0: queue_free()
