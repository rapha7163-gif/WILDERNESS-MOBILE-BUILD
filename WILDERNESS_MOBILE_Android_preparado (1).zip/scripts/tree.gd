extends Node3D

signal felled(wood: int, world_position: Vector3)
var hits := 0
var max_hits := 5
var falling := false
var trunk_body: StaticBody3D

func _ready() -> void:
    _build()

func _material(color: Color, roughness := 1.0) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = roughness
    return m

func _build() -> void:
    var bark := StandardMaterial3D.new()
    bark.albedo_texture = load("res://textures/bark_detail.png")
    bark.roughness = 1.0

    trunk_body = StaticBody3D.new()
    trunk_body.name = "Trunk"
    add_child(trunk_body)

    var trunk := MeshInstance3D.new()
    var cylinder := CylinderMesh.new()
    cylinder.top_radius = 0.38
    cylinder.bottom_radius = 0.62
    cylinder.height = 5.6
    cylinder.radial_segments = 16
    trunk.mesh = cylinder
    trunk.material_override = bark
    trunk.position.y = 2.8
    trunk_body.add_child(trunk)

    var collision := CollisionShape3D.new()
    var shape := CylinderShape3D.new()
    shape.radius = 0.62
    shape.height = 5.6
    collision.shape = shape
    collision.position.y = 2.8
    trunk_body.add_child(collision)

    var cut := MeshInstance3D.new()
    var disk := CylinderMesh.new()
    disk.top_radius = 0.385
    disk.bottom_radius = 0.385
    disk.height = 0.035
    cut.mesh = disk
    cut.position.y = 5.62
    cut.material_override = _material(Color(0.57,0.42,0.28))
    add_child(cut)

    var branch_mat := _material(Color(0.25,0.16,0.10))
    for i in range(5):
        var branch := MeshInstance3D.new()
        var bm := CylinderMesh.new()
        bm.top_radius = 0.06
        bm.bottom_radius = 0.14
        bm.height = 1.7
        branch.mesh = bm
        branch.material_override = branch_mat
        branch.position = Vector3(cos(i*1.25)*0.7,3.7+i*0.25,sin(i*1.25)*0.7)
        branch.rotation_degrees = Vector3(25,0,(-35 if i%2==0 else 35))
        add_child(branch)

    for i in range(9):
        var crown := MeshInstance3D.new()
        var sphere := SphereMesh.new()
        sphere.radius = randf_range(1.1,1.65)
        sphere.height = sphere.radius*1.6
        crown.mesh = sphere
        crown.position = Vector3(randf_range(-1.3,1.3),5.7+randf_range(-0.3,2.0),randf_range(-1.3,1.3))
        crown.scale = Vector3(1.0,0.85,1.0)
        crown.material_override = _material(Color(0.16+randf()*0.07,0.31+randf()*0.10,0.17+randf()*0.05))
        add_child(crown)

func chop(hit_position: Vector3) -> int:
    if falling: return hits
    hits += 1
    var scar := MeshInstance3D.new()
    var scar_mesh := BoxMesh.new()
    scar_mesh.size = Vector3(0.12 + hits*0.025,0.32,0.05)
    scar.mesh = scar_mesh
    scar.position = Vector3(0.0,clampf(to_local(hit_position).y,0.7,4.8),-0.635)
    scar.rotation_degrees.z = randf_range(-12,12)
    scar.material_override = _material(Color(0.075,0.045,0.03))
    add_child(scar)
    if hits >= max_hits:
        _fall()
    return hits

func _fall() -> void:
    falling = true
    trunk_body.queue_free()
    var direction := 1.0 if randf()>0.5 else -1.0
    var tween := create_tween()
    tween.tween_property(self,"rotation:z",deg_to_rad(direction*82.0),1.35).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN)
    tween.tween_callback(func(): felled.emit(6,global_position))
